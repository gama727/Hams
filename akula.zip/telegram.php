<?php
$id_telegram = "1771184667";
$id_botTele  = "7473570749:AAFblkDgOemH09Zo8Z4kf7Kjma7bGHCrMYE";
?>
